# OpenWeatherMap Font

## About
OpenWeatherMap Font is designed to match to response codes from OpenWeatherMap API. CSS rules are based on Font-Awesome font, symbols are created by Deniz Fuchidzhiev (websygen.com).

## Demo
http://websygen.github.io/owfont/

## License
* owfont licensed under SIL OFL 1.1
* Code licensed under MIT License
* Documentation licensed under CC BY 3.0
