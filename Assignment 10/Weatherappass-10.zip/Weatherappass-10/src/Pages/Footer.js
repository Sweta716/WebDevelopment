import React from 'react';

function Footer() {
  return (
    <footer>
      &copy; 2023 Weather App
    </footer>
  );
}

export default Footer;
