import React from 'react';

function Header() {
  return (
    <header>
      Weather App
    </header>
  );
}

export default Header;
