 1. Name : Jatin Parmar
	NUID : 002193739
		
 2. Aplication Details: 
	- The application takes inputs such as text, radio button, checkboxes to fill the form and validate the fields.
	- Validation is implemented on the fields.
	- "Regex" is used to validate the fields on the type of input.
	- Error message appears to the user if the submit button is clicked with any field empty.

	- Once the user fills all the required details in the form and after successful validation, the user will 
	be navigated to next page on click of submit button where the user will be able to see all the filled data.