import bonie from "../Images/image-coffee.jpg";
import utsav from "../Images/image-coffee2.jpg";
import rohit from "../Images/image-coffee3.jpeg";
import puranjai from "../Images/image-coffee4.jpg";

const about = [
  {
    _id: "1",
    title: "Ibrahim Haleem Khan",
    image: utsav,
    content:
      "I made a few new friends and its a great place to hangout as I am always alone.",
  },
  {
    _id: "2",
    title: "MamtaShree",
    image: rohit,
    content: "Its a great place for the dates, I go on many",
  },
  {
    _id: "3",
    title: "Amrutha",
    image: puranjai,
    content: "Finished 2 seasons of Attack on Titan and My Hero academia at this coffee shop.",
  },
  {
    _id: 4,
    title: "Palash",
    image: bonie,
    content:
      "I have played music here, this is a great place for the music ",
  },
];

export default about;
