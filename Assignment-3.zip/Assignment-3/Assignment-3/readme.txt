This is a JavaScript project that has a checkbox tool.
The aim of this project is to understand javascript and build a website where you can add the new student or delete the existing one.
